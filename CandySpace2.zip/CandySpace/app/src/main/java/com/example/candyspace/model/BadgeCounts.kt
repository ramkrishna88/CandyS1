package com.example.candyspace.model

data class BadgeCounts(
    val bronze: Int,
    val gold: Int,
    val silver: Int
)