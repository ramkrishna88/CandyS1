package com.example.candyspace.viewModel

import com.example.candyspace.repository.StackExchangeRepository
import com.example.candyspace.service.StackApi
import io.mockk.clearAllMocks
import io.mockk.mockk
import io.mockk.mockkClass
import junit.framework.TestCase
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.junit.Assert.*

import org.junit.After
import org.junit.Before
import org.junit.Test
import java.nio.channels.ShutdownChannelGroupException
import java.security.Provider


@ExperimentalCoroutinesApi
class StackExchangeViewModelTest : TestCase(){
    private val mockkIoDispatcher = mockk<CoroutineDispatcher>(relaxed = true)


    public override fun setUp() {
        super.setUp()
    }

    public override fun tearDown() {}

    @Test
    fun getQuestions() {
        mockkIoDispatcher
        getQuestions()
    }

    @Test
    fun getSearchedQuestions() {
        mockkIoDispatcher
        getSearchedQuestions()
    }

    @Test
    fun getTaggedQuestions() {
        mockkIoDispatcher
        getTaggedQuestions()
    }

    @Test
    fun getActiveQuestions() {
        mockkIoDispatcher
        getActiveQuestions()
    }

    @Test
    fun searchQuestions() {
        mockkIoDispatcher
        getSearchedQuestions()
    }

    @Test
    fun searchWithFilterTags() {
        mockkIoDispatcher
        getTaggedQuestions()
    }
    @After
    fun shutdown() {
        clearAllMocks(true)
    }

}


