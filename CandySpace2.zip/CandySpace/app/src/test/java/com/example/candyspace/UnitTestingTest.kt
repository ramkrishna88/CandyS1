package com.example.candyspace


import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(JUnit4::class)
class UnitTestingTest {

    @Test
    fun `empty username return false`(){
        val result = UnitTesting.validViewModel(
            "",
            "123",
            "123"
        )
        assertThat(result).isFalse()
    }

    @Test
    fun `valid user name password repeated correctly`(){
        val result = UnitTesting.validViewModel(
            "ramakrishna",
            "123",
            "123"
        )
        assertThat(result).isTrue()
    }

    @Test
    fun `valid username repeated password incorrect`(){
        val result = UnitTesting.validViewModel(
            "ramakrishna",
            "123",
            "456"
        )
        assertThat(result).isFalse()
    }

    @Test
    fun `username already exists return false`(){
        val result = UnitTesting.validViewModel(
            "ramakrishna",
            "123",
            "123"
        )
        assertThat(result).isTrue()
    }

    @Test
    fun `username already exists and password incorrect false`(){
        val result = UnitTesting.validViewModel(
            "ramakrishna",
            "123",
            "123"
        )
        assertThat(result).isTrue()
    }
    private fun assertThat(result: Boolean) {}
    private fun Unit.isTrue() {}
    private fun Unit.isFalse() {}}
