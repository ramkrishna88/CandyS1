package com.example.candyspace.repository

import com.example.candyspace.service.StackApi
import javax.inject.Inject

class StackExchangeRepository @Inject constructor(private val stackApi: StackApi) {

    suspend fun fetchQuestions() = stackApi.fetchQuestions()

    suspend fun searchQuestions(query: String) = stackApi.searchQuestions(query = query)

    suspend fun searchWithFilterTags(tags: String) = stackApi.searchWithFilterTags(tags = tags)

}