package com.example.candyspace.utils

class Constants {

    companion object{
        const val BASE_URL = "https://api.stackexchange.com/"
        const val API_KEY = "ZiXCZbWaOwnDgpVT9Hx8IA(("
    }
}